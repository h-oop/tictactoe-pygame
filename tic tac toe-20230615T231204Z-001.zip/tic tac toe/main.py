# tic tac toe?

import pygame
import os

# init screen stuff
WIDTH, HEIGHT = 600,600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("TIC TAC TOE")
CELL_SIZE = 200
GRID_SIZE = 3

# init colours
WHITE = (255,255,255)
BLACK = (0,0,0)
RED = (255,0,0)
BLUE = (0,0,255)


X_IMG = pygame.image.load(os.path.join('Assets', 'x.png'))
O_IMG = pygame.image.load(os.path.join('Assets', 'o.png'))

grid = [
    [None, None, None], 
    [None, None, None], 
    [None, None, None]
]

def drawwindow():
    WIN.fill(WHITE)
    for i in range(1, GRID_SIZE):
        pygame.draw.line(WIN, BLACK, (i * CELL_SIZE, 0), (i * CELL_SIZE, HEIGHT))
        pygame.draw.line(WIN, BLACK, (0, i * CELL_SIZE), (WIDTH, i * CELL_SIZE))

    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            cell_des = grid[row][col]
            if cell_des == 'x':
                WIN.blit(X_IMG, (col * CELL_SIZE, row * CELL_SIZE))
            if cell_des == 'o':
                WIN.blit(O_IMG, (col * CELL_SIZE, row * CELL_SIZE))

def windetect():
    for row in grid:
        if all(cell == 'x' for cell in row):
            return 'x'
        if all(cell == 'o' for cell in row):
            return 'o'
    if (grid[0][0]==grid[1][1]==grid[2][2]):
        return grid[0][0]
    if (grid[2][0]==grid[1][1]==grid[0][2]):
        return grid[2][0]
    return None


def main():
    global current_p
    current_p = 'x'

    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
    
            if event.type == pygame.MOUSEBUTTONDOWN:
                cell_x = event.pos[0] // CELL_SIZE
                cell_y = event.pos[1] // CELL_SIZE
                
                if grid[cell_y][cell_x] == None:
                    grid[cell_y][cell_x] = current_p
                    # change player
                    if current_p == 'x':
                        current_p = 'o'
                    elif current_p == 'o':
                        current_p = 'x'
        
        if windetect():
            run = False

        drawwindow()
        pygame.display.update()


main()